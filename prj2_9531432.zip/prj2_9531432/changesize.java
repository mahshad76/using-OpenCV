import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.Size;

import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class changesize {
    public static void main(String args[]) throws IOException {
        System.loadLibrary( Core.NATIVE_LIBRARY_NAME );
        String file = "C:\\Users\\mahnoosh\\Desktop/GeeksforGeeks.jpg";
        Mat src = Imgcodecs.imread(file);
        Mat dst = new Mat();

        Imgproc.resize(src, dst, new Size(src.rows()/5, src.rows()/5), 0, 0,
                Imgproc.INTER_AREA);

        //Writing the image
        File f=new File("C:\\Users\\mahnoosh\\Desktop/out_resize.jpg");
        Imgcodecs.imwrite("C:\\Users\\mahnoosh\\Desktop/resize.jpg", dst);
        String file2 = "C:\\Users\\mahnoosh\\Desktop/resize.jpg";
        Mat image = Imgcodecs.imread(file2);
        MatOfByte matOfByte = new MatOfByte();
        Imgcodecs.imencode(".jpg", image, matOfByte);
        byte[] byteArray = matOfByte.toArray();
        InputStream in2 = new ByteArrayInputStream(byteArray);
        BufferedImage bufImage = ImageIO.read(in2);
        JFrame frame = new JFrame();
        frame.getContentPane().add(new JLabel(new ImageIcon(bufImage)));
        frame.pack();
        frame.setVisible(true);

        System.out.println("Image Loaded");
        System.out.println("Image Processed");
    }
}