import javafx.scene.image.Image;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import javax.imageio.ImageIO;
import javax.swing.*;

public class greenImage {
    public static void main(String[] args) throws IOException {
        BufferedImage img = null;
        File f = null;
        try {
            f = new File("C:\\Users\\mahnoosh\\Desktop/GeeksforGeeks.jpg");
            img = ImageIO.read(f);

        } catch (IOException e) {
            System.out.print(e);
        }
        int width = img.getWidth();
        int height = img.getHeight();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int p = img.getRGB(x, y);
                int a = (p >> 24) & 0xff;
                int g = (p >> 8) & 0xff;
                p = (a << 24) | (g << 8) | (0 << 16);
                img.setRGB(x,y,p);


            }
        }

            {
                f=new File("C:\\Users\\mahnoosh\\Desktop/out_change color.jpg");
                ImageIO.write(img,"jpg",f);
            }


    }

}