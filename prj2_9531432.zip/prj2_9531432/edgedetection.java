package ocv;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class edgedetection{
    public static void main(String[] args) throws IOException {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        Mat color= Imgcodecs.imread("C:\\Users\\mahnoosh\\Desktop/GeeksforGeeks.jpg");
        Mat gray=new Mat();
        Mat draw=new Mat();
        Mat wide=new Mat();
        Imgproc.cvtColor(color,gray,Imgproc.COLOR_BGR2GRAY);
        Imgproc.Canny(gray,wide,50,150,3,false);
        wide.convertTo(draw, CvType.CV_8U);
        File f=new File("C:\\Users\\mahnoosh\\Desktop/detection.jpg");
        if(Imgcodecs.imwrite("C:\\Users\\mahnoosh\\Desktop/detection.jpg",draw)){
            System.out.println("edge is detected....");

            String file = "C:\\Users\\mahnoosh\\Desktop/detection.jpg";
            Mat image2 = Imgcodecs.imread(file);
            MatOfByte matOfByte = new MatOfByte();
            Imgcodecs.imencode(".jpg", image2, matOfByte);
            byte[] byteArray = matOfByte.toArray();
            InputStream in = new ByteArrayInputStream(byteArray);
            BufferedImage bufImage = ImageIO.read(in);
            JFrame frame = new JFrame();
            frame.getContentPane().add(new JLabel(new ImageIcon(bufImage)));
            frame.pack();
            frame.setVisible(true);

            System.out.println("Image Loaded");


        }

    }
}