import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

class extractframefromvideo{
    public static void main (String args[]){
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        VideoCapture cap = new VideoCapture();

        String input = "C:\\Users\\mahnoosh\\Desktop/IMG_0633.MOV";
        String output = "C:\\Users\\mahnoosh\\Desktop/movie";

        cap.open(input);

        int video_length = (int) cap.get(Videoio.CAP_PROP_FRAME_COUNT);
        int frames_per_second = (int) cap.get(Videoio.CAP_PROP_FPS);

        Mat frame = new Mat();

        if (cap.isOpened())
        {
            System.out.println("Video is opened");
            System.out.println("Number of Frames: " + video_length);
            System.out.println(frames_per_second + " Frames per Second");
            System.out.println("Converting Video...");

            cap.read(frame);

            int frame_number=0;
            if (cap.isOpened())
            {
                while(cap.read(frame))
                {
                    Imgcodecs.imwrite(output + "/" + frame_number +".jpg", frame);
                    frame_number++;
                }
                cap.release();
            }

            System.out.println(video_length + " Frames extracted");


        }

        else
        {
            System.out.println("Fail");
        }
    } }