package canny;

import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

public class  GaussianBlur{
public static void main(String[] args) throws IOException {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        Mat im = Imgcodecs.imread("C:\\Users\\mahnoosh\\Desktop\\opencv\\prj001/grayscale.jpg");
        Mat dst = new Mat();
        Imgproc.GaussianBlur(im, dst, new Size(5, 5) ,1 ,1);
        Imgcodecs.imwrite("test2.jpg", dst);



    String file = "C:\\Users\\mahnoosh\\Desktop\\opencv\\prj001/test2.jpg";
    Mat image4 = Imgcodecs.imread(file);
    MatOfByte matOfByte = new MatOfByte();
    Imgcodecs.imencode(".jpg", image4, matOfByte);
    byte[] byteArray = matOfByte.toArray();
    InputStream in4 = new ByteArrayInputStream(byteArray);
    BufferedImage bufImage = ImageIO.read(in4);
    JFrame frame = new JFrame();
    frame.getContentPane().add(new JLabel(new ImageIcon(bufImage)));
    frame.pack();
    frame.setVisible(true);

    System.out.println("Image Loaded");
        }
        }