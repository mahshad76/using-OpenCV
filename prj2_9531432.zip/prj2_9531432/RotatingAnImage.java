import org.opencv.core.*;

import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class RotatingAnImage {
    public static void main(String args[]) throws IOException {

        //Loading the OpenCV core library
        System.loadLibrary( Core.NATIVE_LIBRARY_NAME );

        //Reading the Image from the file and storing it in to a Matrix object
        String file = "C:\\Users\\mahnoosh\\Desktop/GeeksforGeeks.jpg";
        Mat src = Imgcodecs.imread(file);

        //Creating an empty matrix to store the result
        Mat dst = new Mat();

        //Creating the transformation matrix M
        Mat rotationMatrix = Imgproc.getRotationMatrix2D(new Point(1900, 1900), 180, 1);

        //Rotating the given image
        Imgproc.warpAffine(src, dst,rotationMatrix, new Size(src.cols(), src.cols()));

        //Writing the image


        File f=new File("C:\\Users\\mahnoosh\\Desktop/out_rotate.jpg");
        Imgcodecs.imwrite("C:\\Users\\mahnoosh\\Desktop/out_rotate.jpg", dst);

        Mat image = Imgcodecs.imread("C:\\Users\\mahnoosh\\Desktop/out_rotate.jpg");
        MatOfByte matOfByte = new MatOfByte();
        Imgcodecs.imencode(".jpg", image, matOfByte);
        byte[] byteArray = matOfByte.toArray();
        InputStream in4 = new ByteArrayInputStream(byteArray);
        BufferedImage bufImage = ImageIO.read(in4);
        JFrame frame = new JFrame();
        frame.getContentPane().add(new JLabel(new ImageIcon(bufImage)));
        frame.pack();
        frame.setVisible(true);

        System.out.println("Image Loaded");
        System.out.println("Image Processed");
    }
}